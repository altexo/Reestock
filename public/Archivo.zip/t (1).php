<?php echo "PHP version is ", PHP_VERSION; 
echo getcwd();
?>