@extends('layouts.admins')
@section('navbar')
@section('contenido')
	<!--  -->
<!-- Editable table -->

@endsection
@section('footer')