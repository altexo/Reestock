<div class="col-md-12 row mt-0">
    			<div class="col-md-3 mt-2">
				<select class="add-caret browser-default colorful-select dropdown-primary" id="call-supplier" name="supplier[supplier_id]">
				    <option value="" disabled selected>Selecciona una Tienda</option>
				    <option value="1">WALMART</option>
				    <option value="2">LEY</option>
				    <option value="3">SAMS</option>
				    <option value="4">SORIANA</option>
				    <option value="5">EL CANARIO</option>
				</select>
           		
				<div class="md-form form-sm mt-2">
				  
				</div>

			</div>

    			<div class="md-form form-sm mt-2 col-md-3">
				    <input type="number" id="form1" class="form-control" id="purchase_price" name="supplier[purchase_price]">
				    <label for="form1" class="">Precio de compra</label>
				</div>

				<div class="md-form form-sm mt-2 col-md-3">
				    <input type="number" id="form1" class="form-control" id="sell_price" name="supplier[sell_price]">
				    <label for="form1" class="">Precio de venta</label>
				</div>
				<div class="col-md-3 mt-2 "><i class="fa fa-close fa-2x remove-store"></i></div>
</div>