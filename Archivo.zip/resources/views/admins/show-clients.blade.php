@extends('layouts.admins')
@section('navbar')
@section('contenido')
@section('footer')