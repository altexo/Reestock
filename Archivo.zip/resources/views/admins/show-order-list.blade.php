@extends('layouts.admins')
@section('navbar')
@section('contenido')
	
@endsection