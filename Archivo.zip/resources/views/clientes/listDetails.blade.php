@extends('layouts.clients')

@section('estilos_unicos')
@section('navbar')

@section('contenido')

{{ $lista }}
@section('footer')
