<?php $__env->startSection('navbar'); ?>
<?php $__env->startSection('contenido'); ?>
	<table>
		<?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<?php $__currentLoopData = $o; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $op): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<th>ID</th>
				<th></th>
				<tr>
					<td><?php echo e($op->id); ?></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		<?php endif; ?>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>