<?php $__env->startSection('estilos'); ?>
<style type="text/css">
    .form-style{
        padding: 20px;
        background-color: white;
    }
    .body-color
    {
        background-color: #f5f5f5;
    }
    .margin10
    {
        margin-top: 10%;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body_class', 'body-color'); ?>
<?php $__env->startSection('contenedor_class', 'margin10'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="container col-md-4">
    <div class="form-style z-depth-4">
    	<!-- Form login -->
    	<form method="POST" action="<?php echo e(route('admin.login.submit')); ?>">
    		<?php echo e(csrf_field()); ?>

    	   <!-- <p class="h5 text-center mb-4">Sign in</p>-->
            <div class="row justify-content-md-center">
                
                <div class="col-12 col-md-auto">
                    <img class="rounded-circle z-depth-1-half" src="<?php echo e(asset('img/favicon.png')); ?>">
                </div>
               
            </div>
           

                <div class="md-form<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
    	        <i class="fa fa-envelope prefix grey-text"></i>
    	        <input type="text" id="defaultForm-email" class="form-control" name="email" value="<?php echo e(old('email')); ?>">
    	        <label for="defaultForm-email">Correo</label>

    	        <?php if($errors->has('email')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                <?php endif; ?>

    	    </div>

    	    <div class="md-form<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
    	        <i class="fa fa-lock prefix grey-text"></i>
    	        <input type="password" name="password" required id="defaultForm-pass" class="form-control">
    	        <label for="defaultForm-pass">Contraseña</label>
    	        <?php if($errors->has('password')): ?>
                    <span class="help-block">
    	  				<strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
    	    </div>
    		
    		<div class="form-group">
    		    <input type="checkbox" id="checkbox1" class="filled-in" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
    		    <label for="checkbox1">Recuerdame</label>
    		</div>
    	    <div class="text-center">
    	        <button class="btn btn-default ">INICIAR SEIÓN</button>
    	    </div>
    	</form>
    	<!-- Form login -->
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>