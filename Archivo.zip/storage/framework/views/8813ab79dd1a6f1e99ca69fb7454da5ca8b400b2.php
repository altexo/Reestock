<!DOCTYPE html>
<html lang="es" class="<?php echo $__env->yieldContent('html_class'); ?>">
<head>
    <meta charset="utf-8">
    
    <meta name="viewport" content="user-scalable=no, width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('titulo'); ?></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/mdb.min.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.ico')); ?>" type="image/x-icon">
    <link rel="icon" href="<?php echo e(asset('img/favicon.ico')); ?>" type="image/x-icon">
    <?php echo $__env->yieldContent('estilos'); ?>
    <style>
        

    </style>
</head>
<body class="<?php echo $__env->yieldContent('body_class'); ?>">
    <header>
        <?php echo $__env->yieldContent('navbar'); ?>
    </header>
    <main>
        
        <div class="container-fluid <?php echo $__env->yieldContent('contenedor_class'); ?>" id="top">
            <?php echo $__env->yieldContent('contenido'); ?>
            <?php echo $__env->yieldContent('sideCart'); ?>
        </div>
    </main>
    <footer>

        <?php echo $__env->yieldContent('footer'); ?>
    </footer>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-2.2.3.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/tether.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/mdb.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.0/jquery-confirm.min.css">

    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
