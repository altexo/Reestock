
<?php if(session('success')): ?>
			<div class="alert alert-success" role="alert">
  				<?php echo e(session('success')); ?>

			</div>
<?php endif; ?>
<?php if(session('err')): ?>
			<div class="alert alert-danger" role="alert">
  				<?php echo e(session('err')); ?>

			</div>
<?php endif; ?>