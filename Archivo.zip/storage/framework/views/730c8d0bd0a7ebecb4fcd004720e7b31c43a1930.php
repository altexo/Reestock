<?php $__env->startSection('estilos_unicos'); ?>
<style type="text/css">
	.table-wrapper {
	    display: block;
	    max-height: 300px;
	    overflow-y: auto;
	    -ms-overflow-style: -ms-autohiding-scrollbar;
	}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('navbar'); ?>
<?php $__env->startSection('contenido'); ?>
	<a href="<?php echo e(URL::previous()); ?>" class="btn btn-danger btn-sm"><i class="fa fa-arrow-left"></i> Volver</a>
	<?php if($status == 4): ?>
		<a class="btn btn-success btn-sm" id="done"><i class="fa fa-check"></i>Marcar como entregada</a>
	<?php endif; ?>
	 <form method="post" action="" id="actions">
	 	<?php echo e(csrf_field()); ?>

		<table class="table table-hover">
		  	<thead>
		    	<tr>
		    		 <th>
                            <input type="checkbox" id="checkbox-all">
                            <label for="checkbox-all" class="mr-2 label-table">Todos</label>
                        </th>
		      		<th>#</th>
		      		<th>Producto</th>
		      		<th>Cantidad</th>
		      		<th>Marca</th>
		    </tr>
		  </thead>
		 
		  <tbody>
		  <?php $n = 0; ?>
			  	<?php $__empty_1 = true; $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			  		<?php $n++; ?>
				    <tr>

		               
		               
		                
				    	<input type="hidden" name="listID[]" value="<?php echo e($item->l_id); ?>">
				      	<th scope="row"> 
				      		<input type="checkbox" id="checkbox<?php echo e($n); ?>">  
				      		<label for="checkbox<?php echo e($n); ?>" class="label-table"><?php echo e($item->products_id); ?></label>
				      	</th>
				      	<td><?php echo e($item->product_name); ?></td>
				      	<td><?php echo e($item->quantity); ?></td>
				      	<td><?php echo e($item->brand); ?></td>
				    </tr>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<?php endif; ?>
			
		  </tbody>
		
		</table>
		  </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts_unicos'); ?>
	<script type="text/javascript">
		 $('.mdb-select').material_select();

		 $('#done').click(function(e){
		 	 e.preventDefault();
            $.confirm({
                title: 'Confirmar',
                content: '¿Seguro deseas marcar esta lista como entregada?',
                type: 'green',
                buttons:{
                    confirmar: {
                        text: 'Si',
                        btnClass: 'btn-green',
                        action: function(){
                            	$('#actions').attr('action', "<?php echo e(route('delivered.done')); ?>").submit();	
                            //$.alert('Ok :)');
                        }
                    },
                    cancelar: {
                        btnClass: 'btn-dark',
                        action: function () {

                        }

                    },
                }
            });
		 
		 });

		 $('body').on('change', '#checkbox-all', function(){
		 	var allCheckboxes = $('[type=checkbox]');
		 	 if ($(this).is(":checked")) {
      			$(allCheckboxes).attr('checked', true);

    		}else if($(this).attr("checked") == true){
    			$(allCheckboxes).attr('checked', false);
    		}
		 
		 });
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>