<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
	<th scope='row'><?php echo e($product->id); ?></th>
	<td><?php echo e($product->product_name); ?></td>
	<td><?php echo e($product->department_name); ?></td>
	<td><?php echo e($product->brand); ?></td><td><?php echo e($product->unity); ?></td>
	<td><?php echo e($product->purchase_price); ?></td>
	<td><?php echo e($product->sale_price); ?></td>
	<td> <i class="fa fa-eye"></i> <a href="<?php echo e(route('Editar Producto', ['id' => $product->id])); ?>"><i class="fa fa-edit"></i></a><a href="<?php echo e(route('product.delete', ['id' => $product->id])); ?>"><i class="fa fa-trash"></i></a> 
	</td>
</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>