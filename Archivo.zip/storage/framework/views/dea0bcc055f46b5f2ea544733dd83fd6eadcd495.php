<?php $__env->startSection('estilos'); ?>

<?php echo $__env->yieldContent('estilos_unicos'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?> <!--Navbar-->
        <nav class=" nav navbar fixed-top navbar-toggleable-md navbar-dark red darken-4 scrolling-navbar">
            <div class="container">
                
                <a class="navbar-brand" href="<?php echo e(url('/paciente')); ?>">
                    <!--<img src="<?php echo e(asset('')); ?>" class="img-fluid flex-center">-->
                    Reestock
                </a>
                <div class="collapse navbar-collapse" id="navbarNav1">
            		<ul class="navbar-nav ml-auto">
            			<li class="nav-item">
                    		<a class="nav-link"><strong>Ayuda</strong></a>
                		</li>
                		<?php if(Auth::guest()): ?>
                		<li class="nav-item">
                    		<a href="<?php echo e(url('paciente/registro')); ?>" class="nav-link"><strong>Regístrate</strong></a>
                		</li>
                 		<li class="nav-item">
                    		<a class="nav-link"><strong>Iniciar sesión </strong></a>
                		</li>
                		<?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
            		</ul>
           
        		</div>
            </div>
        </nav>
        <!--/.Navbar-->
              
                
<?php $__env->stopSection(); ?>


<?php $__env->startSection('contenido'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
                
<!--Footer-->
	<footer class="page-footer center-on-small-only red lighten-1 bottom">

	    <!--Footer Links-->
	    <div class="container">
	        <div class="row">

	            <!--First column-->
	            <div class="col-md-4">
	                <h5 class="title mb-4 mt-3 font-bold">Footer Content</h5>
	                <p>Here you can use rows and columns here to organize your footer content. Lorem ipsum dolor sit
	                    amet, consectetur adipisicing elit.</p>
	            </div>
	            <!--/.First column-->

	            <hr class="clearfix w-100 d-md-none">

	            <!--Second column-->
	            <div class="col-md-2 mx-auto">
	                <h5 class="title mb-4 mt-3 font-bold">Links</h5>
	                <ul>
	                    <li><a href="#!">Link 1</a></li>
	                    <li><a href="#!">Link 2</a></li>
	                    <li><a href="#!">Link 3</a></li>
	                    <li><a href="#!">Link 4</a></li>
	                </ul>
	            </div>
	            <!--/.Second column-->

	            <hr class="clearfix w-100 d-md-none">

	            <!--Third column-->
	            <div class="col-md-2 mx-auto">
	                <h5 class="title mb-4 mt-3 font-bold">Links</h5>
	                <ul>
	                    <li><a href="#!">Link 1</a></li>
	                    <li><a href="#!">Link 2</a></li>
	                    <li><a href="#!">Link 3</a></li>
	                    <li><a href="#!">Link 4</a></li>
	                </ul>
	            </div>
	            <!--/.Third column-->

	            <hr class="clearfix w-100 d-md-none">

	            <!--Fourth column-->
	            <div class="col-md-2 mx-auto">
	                <h5 class="title mb-4 mt-3 font-bold ">Links</h5>
	                <ul>
	                    <li><a href="#!">Link 1</a></li>
	                    <li><a href="#!">Link 2</a></li>
	                    <li><a href="#!">Link 3</a></li>
	                    <li><a href="#!">Link 4</a></li>
	                </ul>
	            </div>
	            <!--/.Fourth column-->
	        </div>
	    </div>
	    <!--/.Footer Links-->

	    <hr>

	    <!--Call to action-->
	    <div class="call-to-action">
	        <ul>
	            <li>
	                <h5 class="mb-1">Registrate y comienza a crear listas Reestock!</h5>
	            </li>
	            <li><a href="" class="btn btn-danger btn-rounded">Registrarme!</a></li>
	        </ul>
	    </div>
	    <!--/.Call to action-->

	    <hr>

	    <!--Social buttons-->
	    <div class="social-section text-center">
	        <ul>

	            <li><a class="btn-floating btn-sm btn-fb"><i class="fa fa-facebook"> </i></a></li>
	            <li><a class="btn-floating btn-sm btn-tw"><i class="fa fa-twitter"> </i></a></li>
	            <li><a class="btn-floating btn-sm btn-gplus"><i class="fa fa-google-plus"> </i></a></li>
	            <li><a class="btn-floating btn-sm btn-li"><i class="fa fa-linkedin"> </i></a></li>
	            <li><a class="btn-floating btn-sm btn-dribbble"><i class="fa fa-dribbble"> </i></a></li>

	        </ul>
	    </div>
	    <!--/.Social buttons-->

	    <!--Copyright-->
	    <div class="footer-copyright">
	        <div class="container-fluid">
	            © 2017 Copyright: <a href="#"> Reestock.com </a>

	        </div>
	    </div>
	    <!--/.Copyright-->

</footer>
	<!--/.Footer-->
	                
	            
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>