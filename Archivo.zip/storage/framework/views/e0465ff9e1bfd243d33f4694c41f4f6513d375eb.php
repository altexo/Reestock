<tr>
    <td class="header text-white">
        <a href="<?php echo e($url); ?>">
            <img src="http://reestock.com.mx/img/rsz_reestock.png">
        </a>
    </td>
</tr>
