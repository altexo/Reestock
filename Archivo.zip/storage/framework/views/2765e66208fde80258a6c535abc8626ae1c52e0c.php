<?php $__env->startSection('navbar'); ?>
<?php $__env->startSection('contenido'); ?>
	<!--  -->
<!-- Editable table -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('layouts.admins', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>