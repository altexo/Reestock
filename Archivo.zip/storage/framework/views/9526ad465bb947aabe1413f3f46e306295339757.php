<?php $__env->startComponent('mail::message'); ?>
# ReeStock de sus proximos productos

Tienes listas proximas a surtir. Recuerda que tienes 24h para realizar cambios antes que tu pedidos se cierre.



<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Ir a mis listas
<?php echo $__env->renderComponent(); ?>


<?php echo $__env->renderComponent(); ?>