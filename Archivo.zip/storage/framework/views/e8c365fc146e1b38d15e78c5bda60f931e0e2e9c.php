<tr style="background-color: #F44336;">
    <td>
        <table class="footer" align="center" width="570" cellpadding="0" cellspacing="0">
            <tr>
                <td class="content-cell" align="center" class="text-white" >
                    <?php echo e(Illuminate\Mail\Markdown::parse($slot)); ?>

                </td>
            </tr>
        </table>
    </td>
</tr>
