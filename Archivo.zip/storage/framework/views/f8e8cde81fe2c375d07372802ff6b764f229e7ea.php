<?php $__env->startSection('estilos_unicos'); ?>
<style type="text/css">
  
.section1{
    padding: 40px;
}
body, html {
    height: 100%;
    margin: 0;
}
.full-height{
    min-height:100vh;
}
/*.container-fluid{
    min-height:100vh;
    background-image: url("<?php echo e(asset('img/Banner-ReeStock.jpg')); ?>");
    background-repeat: no-repeat;
}*/
.bg {

    background-image: url("<?php echo e(asset('img/Banner-ReeStock.jpg')); ?>");
    height: 100%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
}
   .container-fluid {
      padding:0;
      margin:0;

    }
    .margin10 {
            margin-top: 0;
    }
    .red-reestock{
        color: #d32f2f;
    }
    .contact{
       /* background-color: #d32f2f;*/
        padding: 40px;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>

<?php $__env->startSection('contenido'); ?>
<div class="full-height bg">
    
</div>

 <section class="section1">
        
    
    <h1 class="py-3 font-bold text-center red-reestock">¿Cómo lo hacemos?</h1>
    
    <p class="px-5 mb-3 mt-0 pb-2 lead red-text text-center">ReeStock es una empresa creada para facilitar la vida de las personas y ayudarlas a aprovechar cada uno de los minutos de su tiempo en lo que deseen. ¿Cómo lo hacemos? Realizamos todas esas compras que la mayoría de las veces no puedes hacer.</p>


    <div class="row">

        <div class="col-md-4">

            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/iphoneconcorazon.png')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Tus Favoritos</h5>
                    <p class="grey-text">Facilidad para realizar las compras de tus productos favoritos desde tu smartphone.</p>
                </div>
            </div>
       
            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/lista.jpg')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Una Sola Lista</h5>
                    <p class="grey-text">Crea una lista base con diferentes frecuencias, ¡No tendras que preocuparte nunca más!</p>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/pedido.jpg')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Confirma y Espera</h5>
                    <p class="grey-text">72 horas antes de tu entrega se enviará el pedido a tu correo electrónico, y tendrás 24 horas para confirmarlo.</p>
                </div>
            </div>

        </div>

        <div class="col-md-4 mb-2 center-on-small-only flex-center">
            <img src="<?php echo e(asset('img/sniora.jpg')); ?>" alt="" class="z-depth-0">
        </div>

        <div class="col-md-4">

            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/modifica.jpg')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Edita Las Veces Que Quieras*</h5>
                    <p class="grey-text">Puedes modificar tu lista las veces que desees desde la plataforma, quitar o añadir productos y cambiar su frecuencia. </p>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/productoss.jpg')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Productos Locales</h5>
                    <p class="grey-text">Encuentra los productos que tanto te gustan, y tenlos siempre en tu hogar con un solo click.</p>
                </div>
            </div>

            <div class="row mb-2">
                <div class="col-2">
                    <img class="img-fluid" src="<?php echo e(asset('img/tiempoazul.jpg')); ?>">
                </div>
                <div class="col-10 text-left">
                    <h5 class="font-bold red-reestock">Disfruta Tu Tiempo</h5>
                    <p class="grey-text">Usa tu tiempo como nunca antes lo habias hecho, y disfruta las tardes de hacer lo que te gusta.</p>
                </div>
            </div>
        </div>

    </div>
</section>

<section class="contact">
    <div class="row">
        <div class="col-md-6">
            <h2 class="font-bold black-text">¡Contactanos!</h2>
             <p class="px-5 mb-3 mt-0 pb-2 grey-text text-left">Nos encantaría recibir tus comentarios, para sugerencias o aclaraciones escribenos a reestock.mx@gmail.com</p>
        </div>
        <div class="col-md-6">
            

          <!--Google map-->
          <div id="map-container" class="rounded z-depth-1-half map-container" style="height: 400px"></div>

          <br>
          <!--Buttons-->
          <div class="row text-center">
            <div class="col-md-4">
              <a class="btn-floating blue accent-1">
                <i class="fa fa-map-marker"></i>
              </a>
              <p>Av. Kiki Murillo, Edificio Comercial</p>
              <p>Local 102-27</p>
            </div>

            <div class="col-md-4">
              <a class="btn-floating blue accent-1">
                <i class="fa fa-phone"></i>
              </a>
              <p>(667) 189 3640</p>
              <p>Atención a Clientes, 9:00 am - 7:00 pm</p>
            </div>

            <div class="col-md-4">
              <a class="btn-floating blue accent-1">
                <i class="fa fa-envelope"></i>
              </a>
              <p>info@reestock.com.mx</p>
              <p>soporte@reestock.com.mx</p>
            </div>
          </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php $__env->startSection('scripts_unicos'); ?>
<script type="text/javascript">

      function initMap() {
        var uluru = {lat: 24.7388256, lng: -107.393085};
        var map = new google.maps.Map(document.getElementById('map-container'), {
          zoom: 17,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDd1qzOFMZQ5qNxXhUR8jYRPNqblQtHg9g&callback=initMap">
  
        

        </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.clients', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>