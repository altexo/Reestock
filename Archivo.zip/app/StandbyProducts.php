<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StandbyProducts extends Model
{
    protected $table = 'standby_products';
    
}
