<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class List_products extends Model
{
    protected $table = 'list_products';

  
}
