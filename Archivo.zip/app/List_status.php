<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class List_status extends Model
{
    protected $table = 'list_status';

    //  public function list_products(){
    // 	return $this->belongsTo('App\Products');
    // }
}
