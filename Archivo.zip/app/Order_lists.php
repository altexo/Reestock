<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order_lists extends Model
{
     protected $table = 'order_lists';
}
